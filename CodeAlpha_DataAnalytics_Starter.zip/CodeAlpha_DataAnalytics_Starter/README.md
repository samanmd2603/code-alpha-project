# CodeAlpha Data Analytics Internship - Starter Project

This starter project completes two connected tasks:
1. Web Scraping
2. Exploratory Data Analysis (EDA)

## Dataset source
Books to Scrape: https://books.toscrape.com/
This is a demo website intended for scraping practice.

## Requirements
- Python 3.10 or newer
- VS Code (recommended)

## Setup (Windows)
Open this folder in VS Code, then open Terminal > New Terminal.

Install libraries:
```bash
py -m pip install -r requirements.txt
```

## Run Task 1: Web Scraping
```bash
py Task_1_Web_Scraping/scraping.py
```
This collects book titles, prices, ratings, availability and product links from the demo website.
It saves `data/books_data.csv`.

## Run Task 2: EDA
After Task 1 finishes:
```bash
py Task_2_EDA/eda.py
```
This inspects the dataset, reports missing values and duplicates, calculates descriptive statistics,
and saves two charts plus a text summary in the `outputs` folder.

## Evidence/screenshots to capture
Take your own screenshots after running the programs:
1. VS Code terminal showing Task 1 completed and number of books collected.
2. `data/books_data.csv` opened in VS Code or Excel showing the collected rows.
3. VS Code terminal showing Task 2 summary statistics.
4. The two PNG charts opened on your computer.
5. GitHub repository page showing the uploaded project files.

## Important
Run the scripts yourself and check the outputs before submitting. Do not present sample or unrun output
as if it were generated on your computer. Review your internship submission form for its exact requirements.
