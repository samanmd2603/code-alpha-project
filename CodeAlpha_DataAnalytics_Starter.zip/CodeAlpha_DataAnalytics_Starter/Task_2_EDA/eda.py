"""
CodeAlpha Internship - Task 2: Exploratory Data Analysis (EDA)

Run AFTER Task 1:
    python eda.py

Reads:
    ../data/books_data.csv

Creates:
    ../outputs/eda_summary.txt
    ../outputs/price_distribution.png
    ../outputs/average_price_by_rating.png
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = PROJECT_DIR / "data" / "books_data.csv"
OUTPUT_DIR = PROJECT_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

def main():
    if not DATA_FILE.exists():
        print("Dataset not found. First run Task_1_Web_Scraping/scraping.py")
        return

    df = pd.read_csv(DATA_FILE)

    # Basic inspection and data quality checks
    df["price_gbp"] = pd.to_numeric(df["price_gbp"], errors="coerce")
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    missing = df.isnull().sum()
    duplicates = int(df.duplicated(subset=["title"]).sum())

    summary_lines = [
        "CODEALPHA - EXPLORATORY DATA ANALYSIS",
        "=" * 45,
        f"Number of rows (books): {len(df)}",
        f"Number of columns: {len(df.columns)}",
        "",
        "Column data types:",
        df.dtypes.to_string(),
        "",
        "Missing values by column:",
        missing.to_string(),
        "",
        f"Duplicate book titles: {duplicates}",
        "",
        "Price statistics (GBP):",
        df["price_gbp"].describe().to_string(),
        "",
        "Rating counts:",
        df["rating"].value_counts(dropna=False).sort_index().to_string(),
        "",
        "Key observations:",
        f"- Average book price: GBP {df['price_gbp'].mean():.2f}",
        f"- Lowest book price: GBP {df['price_gbp'].min():.2f}",
        f"- Highest book price: GBP {df['price_gbp'].max():.2f}",
        f"- Average rating: {df['rating'].mean():.2f} out of 5",
    ]

    # Chart 1: price distribution
    plt.figure(figsize=(8, 5))
    df["price_gbp"].dropna().hist(bins=20)
    plt.title("Distribution of Book Prices")
    plt.xlabel("Price (GBP)")
    plt.ylabel("Number of Books")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "price_distribution.png", dpi=150)
    plt.close()

    # Chart 2: average price by rating
    avg_by_rating = df.groupby("rating")["price_gbp"].mean()
    plt.figure(figsize=(8, 5))
    avg_by_rating.plot(kind="bar")
    plt.title("Average Book Price by Rating")
    plt.xlabel("Rating (out of 5)")
    plt.ylabel("Average Price (GBP)")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "average_price_by_rating.png", dpi=150)
    plt.close()

    summary_file = OUTPUT_DIR / "eda_summary.txt"
    summary_file.write_text("\n".join(summary_lines), encoding="utf-8")

    print("\n".join(summary_lines))
    print(f"\nCharts and summary saved in: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
