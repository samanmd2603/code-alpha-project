"""
CodeAlpha Internship - Task 1: Web Scraping
Source: https://books.toscrape.com/ (a demo website made for scraping practice)

Run:
    python scraping.py

Output:
    ../data/books_data.csv
"""
from pathlib import Path
import time
import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import urljoin

BASE_URL = "https://books.toscrape.com/"
PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
OUTPUT_FILE = DATA_DIR / "books_data.csv"

RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}

def scrape_books():
    all_books = []
    page_url = BASE_URL
    page_number = 1

    while page_url:
        print(f"Reading page {page_number}: {page_url}")
        response = requests.get(
            page_url,
            headers={"User-Agent": "Mozilla/5.0 (compatible; StudentDataAnalyticsProject/1.0)"},
            timeout=20
        )
        response.raise_for_status()
        soup = BeautifulSoup(response.text, "html.parser")

        for item in soup.select("article.product_pod"):
            title = item.h3.a.get("title", "").strip()
            price_text = item.select_one(".price_color").get_text(strip=True)
            price = float(price_text.replace("£", "").replace("Â", ""))
            rating_class = item.select_one("p.star-rating").get("class", [])
            rating_word = next((word for word in rating_class if word != "star-rating"), "")
            availability = item.select_one(".availability").get_text(" ", strip=True)
            relative_link = item.h3.a.get("href", "")
            product_url = urljoin(page_url, relative_link)

            all_books.append({
                "title": title,
                "price_gbp": price,
                "rating": RATING_MAP.get(rating_word),
                "availability": availability,
                "product_url": product_url
            })

        next_link = soup.select_one("li.next a")
        page_url = urljoin(page_url, next_link["href"]) if next_link else None
        page_number += 1
        time.sleep(0.2)  # small pause between requests

    return pd.DataFrame(all_books)

def main():
    try:
        df = scrape_books()
        df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8")
        print(f"\nSuccess! Collected {len(df)} books.")
        print(f"CSV saved at: {OUTPUT_FILE}")
        print(df.head())
    except requests.RequestException as error:
        print(f"Website/network error: {error}")
    except Exception as error:
        print(f"Something went wrong: {error}")

if __name__ == "__main__":
    main()
